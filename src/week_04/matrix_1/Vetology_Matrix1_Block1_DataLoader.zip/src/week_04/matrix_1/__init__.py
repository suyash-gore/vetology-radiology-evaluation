"""Matrix 1: Vetology-provided ground-truth evaluation workflow."""
