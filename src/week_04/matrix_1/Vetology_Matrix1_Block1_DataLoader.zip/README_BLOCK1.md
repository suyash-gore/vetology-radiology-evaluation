# Matrix 1 — Block 1: Ground-truth data loader

This block creates a Matrix 1-specific loader without modifying the existing
Week 4 / Matrix 2 files.

## Files

Place this folder at:

`src/week_04/matrix_1/`

- `__init__.py`
- `matrix1_data_loader.py`
- `test_matrix1_data_loader.py`

## Input workbook

Use the processed workbook:

`Vetology_Matrix1_First100_Encoded.xlsx`

The loader expects worksheet `Sheet1`, the first 100 populated cases, and the
20 condition columns encoded using exactly `Positive` / `Negative`.

## Data boundary

The loader keeps two separate objects:

- `dataset.cases`: CaseID for local tracking plus original radiologist
  Findings, Conclusions, and Recommendations.
- `dataset.ground_truth`: the 20 Vetology labels for each CaseID, reserved
  exclusively for evaluation.

`case.to_llm_payload()` returns exactly the three original radiologist report
fields. It does not include CaseID, AI-generated report fields, or ground-truth
labels.

## Run tests

From the repository root, with the project virtual environment activated:

```powershell
$env:PYTHONPATH = "src"
python -m unittest discover -s src/week_04/matrix_1 -p "test_*.py" -v
```

These tests use temporary synthetic workbooks and do not call the OpenAI API.

## Status

Block 1 only: Matrix 1 input loading and data-boundary validation.
No OpenAI requests, batch predictions, or confusion-matrix calculations are
performed in this block.
