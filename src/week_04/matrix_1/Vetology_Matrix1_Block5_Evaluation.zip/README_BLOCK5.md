# Matrix 1 — Block 5: Evaluation Workbook

This block evaluates **Matrix 1 only**. It does not read, combine, or reuse Matrix 2 predictions or metrics.

## Files
- `src/week_04/matrix_1/matrix1_evaluator.py` — validates inputs, calculates metrics, and builds the workbook.
- `tests/test_matrix1_evaluator.py` — unit tests for confusion counts and metrics.

## Requirements
Use the project's existing virtual environment and dependencies. `openpyxl` is required.

## Run from repository root (PowerShell)
```powershell
$env:PYTHONPATH = "src"
python -m unittest discover -s tests -p "test_matrix1_evaluator.py" -v

python src/week_04/matrix_1/matrix1_evaluator.py `
  --ground-truth "path\to\Vetology_Matrix1_First100_Encoded.xlsx" `
  --predictions "path\to\predictions.jsonl" `
  --output "outputs/week_04/matrix_1/matrix1_evaluation_workbook.xlsx"
```

## Workbook sheets
1. `Overall Summary` — micro and macro metrics.
2. `Condition Summary` — TP, FN, TN, FP and condition-level metrics, including a TOTAL row.
3. `Case Predictions` — Gold Standard, prediction, and agreement for every case-condition pair.
4. `Confusion Matrix` — TP/FN/TN/FP, sensitivity, specificity, accuracy, precision, F1, and totals.
5. `Execution Log` — source files, validation status, model/prompt metadata, and evaluation scope.
6. `Metric Definitions` — definitions and undefined-metric handling.

## Metric handling
- TP: Gold Standard Positive / model Positive.
- FN: Gold Standard Positive / model Negative.
- TN: Gold Standard Negative / model Negative.
- FP: Gold Standard Negative / model Positive.
- Undefined condition-level ratios remain blank (`None`); macro means exclude undefined values rather than treating them as zero.
- Micro metrics are calculated from summed confusion counts across all 20 conditions.
- Matrix 1 and Matrix 2 remain separate entities.
