# Matrix 1 — Block 2: single-case OpenAI integration test

## Purpose

Run one fresh Matrix 1 case through the existing Week 4 OpenAI client and V1.3
prompt. Validate the response using the existing strict response validator.

This is an integration smoke test before the 100-case Matrix 1 batch.

## Files

Place both Python files in:

`src/week_04/matrix_1/`

- `run_matrix1_single_case_test.py`
- `test_matrix1_single_case_test.py`

Block 2 reuses, without modifying:

- `src/week_04/llm_client.py`
- `src/week_04/prompts/canine_thorax_prompt.py`
- `src/week_04/prompts/canine_thorax_master_prompt_v1_3.txt`
- `src/week_04/response_validator.py`
- `src/week_04/matrix_1/matrix1_data_loader.py`

## Run offline tests first

From the repository root, with `.venv` activated:

```powershell
$env:PYTHONPATH = "src"
python -m unittest discover -s src/week_04/matrix_1 -p "test_*.py" -v
```

These tests use a fake classifier and temporary workbook. They make no API calls.

## Run the live single-case test

Ensure the repository-root `.env` contains a valid `OPENAI_API_KEY` and model
configuration. Do not paste the key into the terminal or source code.

```powershell
$env:PYTHONPATH = "src"
python src/week_04/matrix_1/run_matrix1_single_case_test.py `
  --input "Vetology_Matrix1_First100_Encoded.xlsx" `
  --case-id 1
```

This makes one billable OpenAI API request. To test a different case among the
first 100, change `--case-id`.

## Output separation

The default output is:

`outputs/week_04/matrix_1/single_case_test.json`

This file is deliberately separate from the future batch files:

- `predictions.jsonl`
- `errors.jsonl`

The test artifact stores CaseID for local traceability, model name, V1.3
prompt version, raw model response, and validated 20-condition predictions.
It does not store ground-truth labels and does not calculate metrics.

## Success criteria

- Exactly one selected case is sent to the existing OpenAI client.
- Only original Findings, Conclusions, and Recommendations are passed.
- CaseID, AI-generated report fields, and ground-truth labels are excluded.
- The returned JSON passes the existing strict 20-key Positive/Negative validator.
- A separate single-case test artifact is saved.
