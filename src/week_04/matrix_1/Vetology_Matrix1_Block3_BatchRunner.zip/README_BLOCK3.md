# Matrix 1 — Block 3: 100-case OpenAI batch runner

## Purpose

Run a fresh Matrix 1 batch of 100 cases using the existing Week 4 pipeline:

- Matrix 1 data loader
- Existing LangChain/OpenAI client
- Existing V1.3 prompt
- Existing strict JSON response validator
- Existing resumable batch processor

No existing Week 4 / Matrix 2 source files are modified.

## Files

Place these files in:

`src/week_04/matrix_1/`

- `run_matrix1_batch.py`
- `test_matrix1_batch_runner.py`

The runner expects the Block 1 `matrix1_data_loader.py` to be present in the
same folder and the existing shared Week 4 modules to remain in place.

## Offline tests

From the repository root, with `.venv` activated:

```powershell
$env:PYTHONPATH = "src"
python -m unittest discover -s src/week_04/matrix_1 -p "test_*.py" -v
```

The runner tests mock the loader and batch processor. They do not call OpenAI.

## Before the live batch

Confirm that:

1. Block 1 and Block 2 tests pass.
2. The single-case live test passed.
3. `outputs/week_04/matrix_1/` does not contain old batch `predictions.jsonl`
   or `errors.jsonl` from an unrelated run.
4. The processed Matrix 1 workbook is the intended input.

The batch processor is resumable. If `predictions.jsonl` already contains
valid successful records with matching CaseIDs, those cases will be skipped.
For the first fresh Matrix 1 run, use the dedicated Matrix 1 output directory
and ensure no previous batch checkpoint is present there.

## Live batch command

```powershell
$env:PYTHONPATH = "src"
python src/week_04/matrix_1/run_matrix1_batch.py `
  --input "D:\path\to\Vetology_Matrix1_First100_Encoded.xlsx"
```

Optional arguments:

- `--output-dir "outputs/week_04/matrix_1"`
- `--max-attempts 2`

This can make up to two application-level attempts per case. The LangChain
transport retry setting in `.env` may add HTTP attempts. API usage is billable.

## Output files

```text
outputs/
└── week_04/
    └── matrix_1/
        ├── single_case_test.json
        ├── predictions.jsonl
        └── errors.jsonl
```

The single-case test artifact is not used as a batch checkpoint.

## Data boundary and evaluation

The runner passes only `dataset.cases` to the existing batch processor.
The batch processor calls `case.to_llm_payload()`, which contains only original
radiologist Findings, Conclusions, and Recommendations. Matrix 1 ground-truth
labels remain separate and are not sent to the LLM.

This block only generates and validates predictions. It does not calculate
confusion matrices or compare predictions with ground truth; that is a later
evaluation block.
