# Week 4 Optional Task — JSON Prompt Configuration

## Objective
Demonstrate that the application can read its prompt from a JSON configuration file, as requested by the Week 4 optional assignment.

## Scope
- Uses the existing Canine Thorax Master Prompt V1.3 without changing its wording.
- Loads prompt metadata and prompt text from `config/canine_thorax_v1_3.json`.
- Validates the configuration structure and expected V1.3 version.
- Makes no API calls and does not execute an LLM.
- Does not load datasets, generate predictions, or modify the Matrix 1 implementation.

## Files
- `config/canine_thorax_v1_3.json` — prompt configuration containing V1.3.
- `prompt_config_loader.py` — reads and validates the JSON configuration.
- `test_prompt_config_loader.py` — offline unit tests.

## Run tests
From this directory, using the project's Python environment:

```powershell
python -m unittest -v test_prompt_config_loader.py
```

Expected result: 5 tests pass.

## Load the prompt manually
```python
from prompt_config_loader import load_system_prompt

system_prompt = load_system_prompt()
print(system_prompt)
```

This only reads the local JSON file. It does not send the prompt to an API.
